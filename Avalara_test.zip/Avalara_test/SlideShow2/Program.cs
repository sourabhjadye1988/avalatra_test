﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SlideShow2
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] lines = File.ReadAllLines(@"exampleInput.txt");
            int numberOfPhotos = Convert.ToInt32(lines[0]);
            IShow slideShow = new SlideShow();

            //Adding photos             
            for (int i = 1; i < numberOfPhotos + 1; i++)
            {
                string[] lnSplit = lines[i].Split(' ');
                slideShow.AddPhoto(new Photo(i - 1, Convert.ToChar(lnSplit[0]),lnSplit.Skip(2).ToArray()));
            }

            //Preaparing Slid show
            IDictionary<int, Slide> Show = slideShow.PrepareShow();

            //Putting into Output file
            string outputFile = @"exampleOutput." + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".txt";
            StringBuilder sb = new StringBuilder(Show.Count + Environment.NewLine);
            foreach (int indx in Show.Keys)
            {
                sb.Append(Show[indx].GetFrameNumbers() + Environment.NewLine);
            }
            File.AppendAllText(outputFile, sb.ToString());
            Console.WriteLine(sb.ToString());
            Console.WriteLine("Press Enter  to exit!!");
            Console.ReadLine();
        }
    }
}
