﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SlideShow2
{
    interface IShow
    {
        void AddPhoto(Photo p);
        Dictionary<int, Slide> PrepareShow();
    }
}
