﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SlideShow2
{
    class Photo
    {
        public int Id { get; set; }

        public char Oriantation { get; set; }

        public string[] Tags { get; set; }

        public Photo(int Id,char Orintation,string[] tags)
        {
            this.Id = Id;
            this.Oriantation = Orintation;
            this.Tags = tags;
        }
    }
}
