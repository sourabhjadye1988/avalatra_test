﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SlideShow2
{
    class Slide
    {
        public int Id { get; set; }
        public List<Photo> photos { get; set; }

        public Slide(int Id)
        {
            this.Id = Id;
            photos = new List<Photo>();
        }

        public void AddPhoto(Photo p)
        {
            if (!CanAddPhoto())
                throw new Exception("Slide is Full of Photo(s)!!");
            photos.Add(p);
        }

        public bool CanAddPhoto()
        {
            if (photos.Count == 2)
                return false;
            if (photos.Count == 1 && photos.First().Oriantation == 'H')
                return false;

            return true;
        }

        public string GetFrameNumbers()
        {
            StringBuilder stringBuilder = new StringBuilder();
            photos.ForEach(f => stringBuilder.Append(f.Id + " "));
            return stringBuilder.ToString();
        }

        public int IntrestFactor(Slide othorSlide)
        {
            int intrestFactor=0;
            List<string> currentSlideTags = GetTags();
            List<string> otherSlideTags = othorSlide.GetTags();
            currentSlideTags.ForEach(t =>
            {
                if (otherSlideTags.Contains(t))
                    intrestFactor++;
            });

            return intrestFactor;
        }

        List<string> GetTags()
        {
            List<string> lst = new List<string>();
            photos.ForEach(p => lst.AddRange(p.Tags));
            return lst.Distinct().ToList();
        }
    }
}
