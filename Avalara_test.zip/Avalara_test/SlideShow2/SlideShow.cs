﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SlideShow2
{
    class SlideShow : IShow
    {
        List<Photo> photos = new List<Photo>();
        Dictionary<int, Slide> show = new Dictionary<int, Slide>();
        

        public void AddPhoto(Photo p)
        {
            photos.Add(p);
        }

        public Dictionary<int, Slide> PrepareShow()
        {
            
            //Add all Photos to Slids
            foreach (Photo photo in photos)
            {
                Slide slide = new Slide(0);
                if (photo.Oriantation == 'H')
                {
                    //Photo is Horizontal, add directly to slide show
                    slide.Id = show.Count + 1; 
                    slide.AddPhoto(photo);
                    show.Add(slide.Id, slide);
                }
                else if (photo.Oriantation == 'V')
                {
                    slide = show.Values.ToList().FirstOrDefault(v => v.CanAddPhoto()); //Check if any single photo slide presents in show

                    if (slide != null)
                        slide.AddPhoto(photo);
                    else   //If no then add new slide with vertical photo
                    {
                        slide = new Slide(0);
                        slide.Id = show.Count + 1;
                        slide.AddPhoto(photo);
                        show.Add(slide.Id, slide);
                    }
                }
                else
                    throw new Exception("Invalid Orientation!!");
            }

            //Sort show for Instrest Factor
            int slideCount = show.Count;
            for (int i = 1; i <= slideCount-1; i++)
            {
                for (int j = i+2; j <= slideCount; j++)
                {
                    if (show[i].IntrestFactor(show[j]) == 1)
                    {
                        Slide slide = show[i+1];
                        show[i+1] = show[j];
                        show[j] = slide;
                    }
                }
            }

            return show;
        }
    }
}
